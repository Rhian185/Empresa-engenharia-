/* ===== CONTEÚDO EDITÁVEL ===== */
const CFG={
 company:{name:"F Dois Engenharia",tagline:"Construindo o futuro com experiência."},
 contact:{phone:"+558432343390",phoneLabel:"(84) 3234-3390",whatsapp:"5584988464244",whatsappLabel:"+55 84 98846-4244",address:"R. Dr. Múcio Galvão, 426 - Tirol, Natal - RN, 59020-550"},
 social:{instagram:"https://www.instagram.com/fdoisengenharia/",linkedin:"https://www.linkedin.com/search/results/companies/?keywords=F%20Dois%20Engenharia"}, // troque o LinkedIn pela página oficial
 links:{googleReviews:"https://www.google.com/search?q=F+Dois+Engenharia+Natal+avalia%C3%A7%C3%B5es"}, // troque pelo link oficial das avaliações
 stats:[{to:24,suf:"+",text:"24+",label:"Anos de experiência"},{to:4.9,dec:1,text:"4,9",label:"Estrelas no Google"},{to:8,text:"8",label:"Avaliações no Google"},{to:2.1,dec:1,suf:" mil+",text:"2,1 mil+",label:"Seguidores no Instagram"},{to:230,suf:"+",text:"230+",label:"Seguidores no LinkedIn"}],
 services:[["PROJETOS E PLANEJAMENTO","Transformando necessidades em projetos bem estruturados."],["CONSTRUÇÃO CIVIL","Atuação no desenvolvimento e execução de obras."],["EXECUÇÃO DE OBRAS","Planejamento, acompanhamento e execução de projetos."],["SOLUÇÕES EM ENGENHARIA","Abordagem profissional para diferentes necessidades da construção."]],
 // [rótulo, título, descrição, categoria] — mesma ordem das imagens em PH
 projects:[["Residencial","Projeto em destaque","Espaço para apresentar um projeto de referência da empresa.","Residencial"],["Residencial","Obra residencial","Espaço para apresentar uma obra residencial.","Residencial"],["Residencial","Área de lazer com piscina","Espaço para apresentar uma área de lazer.","Residencial"],["Residencial","Interior residencial","Espaço para apresentar um projeto de interiores.","Residencial"],["Residencial","Residência com piscina","Espaço para apresentar uma residência com área de lazer.","Residencial"],["Residencial","Área externa e piscina","Espaço para apresentar uma área externa com piscina.","Residencial"]],
 differentials:[["EXPERIÊNCIA","Mais de duas décadas de atuação no setor da construção civil.",'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'],["QUALIDADE","Compromisso com a qualidade em projetos e construções.",'<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/>'],["PLANEJAMENTO","Organização e atenção em cada etapa do trabalho.",'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 3v18"/>'],["CREDIBILIDADE","Uma empresa potiguar com presença consolidada.",'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>'],["VISÃO DE FUTURO","Soluções de engenharia pensadas para transformar ideias em realidade.",'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>']],
 testimonial:{name:"Roberto Cesar",role:"Local Guide",text:"Qualidade em projetos e construções, excelentes trabalhos executados e clientes satisfeitos!!!"}
};
const ICO=['<rect x="4" y="3" width="16" height="18" rx="1"/><path d="M8 8h8M8 12h8M8 16h5"/>','<path d="M4 21V9l8-5 8 5v12M9 21v-6h6v6"/>','<path d="M6 21V4M6 4h13M6 8l6-4M17 4v6M15 10h4v3h-4zM3 21h8"/>','<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/>'];
const SKY=id=>`<defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0B2545"/><stop offset=".65" stop-color="#2A5DA8"/><stop offset="1" stop-color="#F2C46B"/></linearGradient></defs><rect width="320" height="300" fill="url(#${id})"/>`;
const WIN=(x,y,c,r,w,h,gx,gy,k)=>{let o="";for(let j=0;j<r;j++)for(let i=0;i<c;i++){const l=(j*7+i*3+k)%5===0;o+=`<rect x="${x+i*gx}" y="${y+j*gy}" width="${w}" height="${h}" fill="${l?"#F6D27A":"#8FB4E6"}" opacity="${l?1:.55}"/>`}return o};
const GND='<rect y="270" width="320" height="30" fill="#071A33"/><rect y="270" width="320" height="3" fill="#E0A526"/>';
const ART={
 d:SKY("s1")+'<rect x="28" y="150" width="72" height="120" fill="#0E2A52"/><rect x="100" y="60" width="92" height="210" fill="#12305C"/><rect x="192" y="120" width="84" height="150" fill="#0E2A52"/>'+WIN(36,160,4,7,9,8,16,15,1)+WIN(108,70,6,14,9,8,14,14,2)+WIN(200,130,5,9,9,8,15,15,3)+'<path d="M245 120V34M195 34h110M245 34l-30 18M290 34v16M258 34v-6" stroke="#E0A526" stroke-width="3" fill="none"/><path d="M215 34v40" stroke="#E0A526" stroke-width="1.5"/><rect x="209" y="74" width="12" height="9" fill="#E0A526"/>'+GND,
 r:SKY("s2")+'<rect x="60" y="175" width="135" height="95" fill="#E8EEF7"/><rect x="95" y="130" width="130" height="45" fill="#F7F9FC"/><rect x="88" y="124" width="144" height="7" fill="#0E2A52"/><rect x="72" y="190" width="72" height="80" fill="#6FA0E0" opacity=".85"/><path d="M96 190v80M120 190v80M72 230h72" stroke="#E8EEF7" stroke-width="2"/><rect x="112" y="142" width="80" height="22" fill="#F6D27A"/><rect x="195" y="195" width="85" height="75" fill="#0E2A52"/><path d="M205 195v75M218 195v75M231 195v75M244 195v75M257 195v75M270 195v75" stroke="#E0A526" stroke-width="3"/><path d="M40 270V205" stroke="#071A33" stroke-width="4"/><path d="M40 205c-18-4-28 6-32 14M40 205c18-4 28 6 32 14M40 205c-10-14-24-14-30-10M40 205c10-14 24-14 30-10" stroke="#2F7A4F" stroke-width="3" fill="none"/>'+GND,
 i:SKY("s3")+'<path d="M40 130h240L160 62z" fill="#E8EEF7"/><rect x="40" y="130" width="240" height="10" fill="#C9D3E3"/><g fill="#F7F9FC"><rect x="58" y="140" width="14" height="116"/><rect x="102" y="140" width="14" height="116"/><rect x="146" y="140" width="14" height="116"/><rect x="190" y="140" width="14" height="116"/><rect x="234" y="140" width="14" height="116"/></g><rect x="30" y="256" width="260" height="8" fill="#C9D3E3"/><rect x="20" y="264" width="280" height="8" fill="#B4C2D9"/><rect x="128" y="200" width="44" height="56" fill="#0E2A52"/><circle cx="160" cy="105" r="9" fill="#E0A526"/>'+GND,
 f:'<defs><linearGradient id="s4" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0B2545"/><stop offset=".6" stop-color="#2A5DA8"/><stop offset="1" stop-color="#F2C46B"/></linearGradient></defs><rect width="320" height="300" fill="url(#s4)"/><rect y="215" width="320" height="85" fill="#0B2545"/><path d="M20 235h280M60 250h200M100 265h120" stroke="#3F6FB5" stroke-width="2" opacity=".6"/><rect y="188" width="320" height="10" fill="#E8EEF7"/><rect x="150" y="50" width="12" height="150" fill="#E8EEF7"/><path d="M156 62L40 188M156 62L80 188M156 62L120 188M156 62L272 188M156 62L232 188M156 62L192 188" stroke="#E0A526" stroke-width="1.6" fill="none"/><path d="M60 198v17M110 198v17M210 198v17M260 198v17" stroke="#C9D3E3" stroke-width="6"/><rect y="212" width="320" height="3" fill="#E0A526"/>'
};
const PH=[["assets/img/projeto-destaque.jpg","50% 46%","assets/video/projeto-destaque.mp4"],["assets/img/obra-residencial.jpg","50% 50%","assets/video/obra-residencial.mp4"],["assets/img/area-lazer-piscina.jpg","50% 50%","assets/video/area-lazer-piscina.mp4"],["assets/img/interior-residencial.jpg","50% 50%","assets/video/interior-residencial.mp4"],["assets/img/residencia-piscina.jpg","50% 50%","assets/video/residencia-piscina.mp4"],["assets/img/area-externa-piscina.jpg","50% 50%","assets/video/area-externa-piscina.mp4"]];
const KEYS=["d","r","i","f"];
const SOL=CFG.services,PROJ=CFG.projects,DIF=CFG.differentials;
const $=s=>document.querySelector(s);
document.documentElement.classList.add("js");
$("#cards").innerHTML=SOL.map((s,i)=>`<article class="card rv"><div class="ch"><i>0${i+1}</i><svg viewBox="0 0 24 24" aria-hidden="true">${ICO[i]}</svg></div><h3>${s[0]}</h3><p>${s[1]}</p></article>`).join("");
$("#dif").innerHTML=DIF.map(d=>`<div class="rv"><svg viewBox="0 0 24 24" aria-hidden="true">${d[2]}</svg><h3>${d[0]}</h3><p>${d[1]}</p></div>`).join("");
const cats=["Todos","Residencial","Institucional","Infraestrutura"];
$("#proj").innerHTML=PROJ.map((p,i)=>`<article class="pcard rv" data-c="${p[3]}"><div class="im" role="button" tabindex="0" aria-label="Ampliar imagem: ${p[1]}"><span class="ill">Imagem ilustrativa</span>${PH[i]?`<img class="ph" loading="lazy" decoding="async" src="${PH[i][0]}" alt="Foto: ${p[1]}" style="object-position:${PH[i][1]}"><video class="ph" data-v muted loop playsinline preload="metadata" aria-hidden="true" src="${PH[i][2]}" style="object-position:${PH[i][1]}"></video>`:`<svg viewBox="0 0 320 300" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Ilustração: ${p[1]}">${ART[KEYS[i]]}</svg>`}</div><div class="tx"><small>${p[0]==="Todos"?"Destaque":p[0]}</small><h3>${p[1]}</h3><p>${p[2]}</p></div></article>`).join("");
const fl=$(".filters");
fl.innerHTML=cats.map((c,i)=>`<button type="button" aria-pressed="${i===0}">${c}</button>`).join("");
fl.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;
 fl.querySelectorAll("button").forEach(x=>x.setAttribute("aria-pressed",x===b));
 document.querySelectorAll(".pcard").forEach(c=>{c.hidden=!(b.textContent==="Todos"||c.dataset.c===b.textContent||(c.dataset.c==="Destaque"&&b.textContent==="Todos"))});});
$("#gLink").href=CFG.links.googleReviews;$("#ig").href=CFG.social.instagram;$("#li").href=CFG.social.linkedin;
const maps="https://www.google.com/maps/search/?api=1&query="+encodeURIComponent(CFG.contact.address);
$("#route").href=maps;$("#mapLink").href=maps;
/* menu */
const hd=$("header"),bg=$(".burger"),nv=$("#menu");
const sc=()=>hd.classList.toggle("on",scrollY>30);sc();addEventListener("scroll",sc,{passive:true});
bg.addEventListener("click",()=>{const o=nv.classList.toggle("open");bg.setAttribute("aria-expanded",o);bg.setAttribute("aria-label",o?"Fechar menu":"Abrir menu");if(o)hd.classList.add("on");else sc()});
nv.addEventListener("click",e=>{if(e.target.closest("a")){nv.classList.remove("open");bg.setAttribute("aria-expanded","false");sc()}});
/* reveal + contadores */
const rm=matchMedia("(prefers-reduced-motion:reduce)").matches;
const fmt=(n,d)=>n.toFixed(d).replace(".",",");
function count(el){const to=+el.dataset.to,d=+(el.dataset.dec||0),suf=el.dataset.suf||"";
 if(rm){el.textContent=fmt(to,d)+suf;return}
 const t0=performance.now(),dur=1400;
 (function step(t){const p=Math.min((t-t0)/dur,1),e=1-Math.pow(1-p,3);el.textContent=fmt(to*e,d)+suf;if(p<1)requestAnimationFrame(step)})(t0);}
const io=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;{const t=e.target,sib=[...t.parentElement.children].indexOf(t),g=t.parentElement.matches(".cards,.dif,.proj,.grid5");setTimeout(()=>t.classList.add("in"),g?Math.min(sib,5)*90:0)}
 e.target.querySelectorAll("[data-to]").forEach(count);io.unobserve(e.target)}),{threshold:.15});
document.querySelectorAll(".rv").forEach(el=>io.observe(el));
/* título animado */
(()=>{const h=document.querySelector(".hero h1"),t=h.textContent.trim();h.setAttribute("aria-label",t);h.textContent="";let k=0;
t.split(" ").forEach((w,wi,a)=>{const sw=document.createElement("span");sw.className="w";sw.setAttribute("aria-hidden","true");
[...w].forEach(c=>{const l=document.createElement("span");l.className="l";l.textContent=c;l.style.setProperty("--i",k++);sw.appendChild(l)});
h.appendChild(sw);if(wi<a.length-1)h.appendChild(document.createTextNode(" "))})})();
/* vídeo da capa */
(()=>{const v=document.getElementById("heroVid");if(!v)return;
if(matchMedia("(prefers-reduced-motion:reduce)").matches){v.removeAttribute("autoplay");v.pause();return}
const go=()=>{const p=v.play();if(p&&p.catch)p.catch(()=>{})};go();document.addEventListener("visibilitychange",()=>{document.hidden?v.pause():go()});})();
/* vídeos: tocam só quando visíveis */
(()=>{const vs=[...document.querySelectorAll("video[data-v]")];
if(matchMedia("(prefers-reduced-motion:reduce)").matches)return;
const vo=new IntersectionObserver(es=>es.forEach(e=>{const v=e.target;if(e.isIntersecting){v.muted=true;const p=v.play();p&&p.catch&&p.catch(()=>{})}else v.pause()}),{threshold:.1});
vs.forEach(v=>vo.observe(v))})();
/* dados -> página */
(()=>{const C=CFG.contact,WA="https://wa.me/"+C.whatsapp,TEL="tel:"+C.phone;
document.querySelectorAll('a[href^="https://wa.me"]').forEach(a=>a.href=WA);
document.querySelectorAll('a[href^="tel:"]').forEach(a=>a.href=TEL);
$(".grid5").innerHTML=CFG.stats.map(x=>`<div><b data-to="${x.to}"${x.dec?` data-dec="${x.dec}"`:""}${x.suf?` data-suf="${x.suf}"`:""}>${x.text}</b><span>${x.label}</span></div>`).join("");
const T=CFG.testimonial;$("blockquote p").textContent="“"+T.text+"”";$("blockquote footer").innerHTML="<strong>"+T.name+"</strong> · "+T.role;})();
/* menu: seção atual */
(()=>{const ls=[...document.querySelectorAll('nav ul a[href^="#"]')];
const so=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)ls.forEach(a=>a.classList.toggle("active",a.getAttribute("href")==="#"+e.target.id))}),{rootMargin:"-45% 0px -50% 0px"});
["inicio","sobre","solucoes","projetos","avaliacoes","contato"].forEach(id=>{const el=document.getElementById(id);el&&so.observe(el)})})();
/* filtros: estado vazio */
fl.addEventListener("click",()=>{$("#empty").hidden=[...document.querySelectorAll(".pcard")].some(c=>!c.hidden)});
/* lightbox */
(()=>{const lb=document.createElement("dialog");lb.id="lb";lb.setAttribute("aria-label","Imagem ampliada");
lb.innerHTML='<button type="button" class="lbx" aria-label="Fechar">×</button><img alt=""><p></p>';document.body.appendChild(lb);
const open=el=>{const im=el.querySelector("img"),x=lb.querySelector("img");x.src=im.src;x.alt=im.alt;lb.querySelector("p").textContent=el.closest(".pcard").querySelector("h3").textContent+" · imagem ilustrativa";lb.showModal()};
const pj=$("#proj");pj.addEventListener("click",e=>{const el=e.target.closest(".im");el&&open(el)});
pj.addEventListener("keydown",e=>{if((e.key==="Enter"||e.key===" ")&&e.target.classList.contains("im")){e.preventDefault();open(e.target)}});
lb.addEventListener("click",e=>{if(e.target===lb||e.target.classList.contains("lbx"))lb.close()})})();
